"""Independent, read-only validator for the completed Gemma benchmark cohort.

It deliberately does not import the benchmark driver.  It refuses to issue a
completion verdict before the driver's final summary exists.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import statistics
from collections import Counter, defaultdict
from pathlib import Path

COMMIT = "51d0a60a1f29231e5762d8b2f830e74c6a972962"
BINARY_SHA256 = "03ede7b272b3fe26111b66bee8a768ee11e685ecf568fe0d85bc1d84d7d80f42"
# The driver hashes the checked-out Windows bytes.  The second hash anchors
# those bytes to the immutable Git blob after CRLF normalization.
SUITE_SHA256 = "f32f971006e80c75fcb25d8116513dc289606dbfb8ea5bc16b1bc97161816530"
SUITE_NORMALIZED_GIT_BLOB_SHA256 = "b7b3e6cf5033e9cfccb79931826cefadd6d9434500458f655e265d6ac6297b22"
ENVIRONMENT_SHA256 = "caf06dd5f6a8e1efdd5545b65064a7997c0e1eb21cd77f8240e745c04d93fcb8"
MODEL = "gemma4:e4b-it-q4_K_M"
MODEL_DIGEST = "c6eb396dbd5992bbe3f5cdb947e8bbc0ee413d7c17e2beaae69f5d569cf982eb"
URL = "http://[::1]:11434"
SUITE = "local-task-agent-strategy-benchmark"
PROMPT = "local-task-agent-benchmark-prompt-1"
CASES = ("dependent-lookup-update", "independent-reads-8")
TASKS8 = [
    {"id": "crux-17", "title": "Pack bag", "status": "queued"},
    {"id": "mist-28", "title": "Pay bill", "status": "blocked"},
    {"id": "amber-39", "title": "Book table", "status": "open"},
    {"id": "nova-44", "title": "Send draft", "status": "review"},
    {"id": "pulse-56", "title": "Water plants", "status": "paused"},
    {"id": "orbit-63", "title": "Read brief", "status": "ready"},
    {"id": "sable-72", "title": "Call mentor", "status": "waiting"},
    {"id": "ember-84", "title": "File receipt", "status": "done"},
]
UPDATE_INITIAL = [{"id": "opaque-7", "title": "Call dentist", "status": "open"}]
UPDATE_FINAL = [{"id": "opaque-7", "title": "Call dentist", "status": "completed"}]


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def planned() -> list[dict]:
    rows = []
    def add(phase, pair, cases, strategies):
        for co, case in enumerate(cases, 1):
            for so, strategy in enumerate(strategies, 1):
                rows.append({"phase": phase, "pair_index": pair, "case_id": case,
                             "requested_strategy": strategy, "case_order": co,
                             "strategy_order": so, "schedule_index": len(rows) + 1})
    add("discovery", 0, CASES, ("direct", "adaptive"))
    add("warmup", 0, CASES, ("direct", "adaptive"))
    for pair in range(1, 31):
        add("measured", pair, CASES if pair % 2 else tuple(reversed(CASES)),
            ("direct", "adaptive") if pair % 2 else ("adaptive", "direct"))
    return rows


def fail(errors, text):
    errors.append(text)


def normref(value: str) -> Path:
    return Path(value.replace("\\", "/"))


def _json_or_none(value):
    try:
        return json.loads(value)
    except (TypeError, json.JSONDecodeError):
        return None


def tool_id(x): return x.get("context", {}).get("tool_id")
def args(x): return x.get("arguments")


def validate_sample(sample, result, slot):
    errors = []
    case = slot["case_id"]
    if result.get("passed") is not True or result.get("failures"):
        fail(errors, "evaluator result was not a clean pass")
    for value, expected, name in ((sample.get("suite_id"), SUITE, "sample suite"),
                                  (result.get("suite_id"), SUITE, "result suite"),
                                  (sample.get("case_id"), case, "sample case"),
                                  (result.get("case_id"), case, "result case"),
                                  (sample.get("model"), MODEL, "sample model"),
                                  (result.get("model"), MODEL, "result model"),
                                  (sample.get("requested_strategy"), slot["requested_strategy"], "sample strategy"),
                                  (result.get("strategy"), slot["requested_strategy"], "result strategy"),
                                  (sample.get("repetition"), 1, "sample repetition"),
                                  (result.get("repetition"), 1, "result repetition")):
        if value != expected: fail(errors, f"{name} mismatch")
    strat = sample.get("strategy", {})
    if strat.get("actual") != "direct": fail(errors, "actual strategy was not direct")
    fallbacks = strat.get("fallbacks")
    if slot["requested_strategy"] == "adaptive":
        if fallbacks != [{"from": "adaptive", "to": "direct", "reason": "UnsupportedCapability"}]:
            fail(errors, "adaptive fallback was not the required UnsupportedCapability fallback")
    elif fallbacks != []: fail(errors, "direct invocation had a fallback")
    calls, policies, approvals, executions = (sample.get(x) for x in ("model_calls", "policy_decisions", "approvals", "tool_executions"))
    if not isinstance(calls, list) or not calls: fail(errors, "no model contact")
    if not all(isinstance(x, list) for x in (policies, approvals, executions)):
        fail(errors, "audit arrays malformed"); return errors
    if sample.get("audit_violations") != []: fail(errors, "audit violations present")
    run = sample.get("run", {})
    if run.get("status") != "completed" or run.get("errors") not in ([], None): fail(errors, "run did not complete cleanly")
    if len(calls) != result.get("model_calls") or len(executions) != result.get("tool_calls"):
        fail(errors, "result metrics disagree with evidence")
    if result.get("run_id") != run.get("id") or not run.get("trace_id"):
        fail(errors, "result/run identity mismatch")
    if not calls or calls[-1].get("response", {}).get("final_output") != run.get("final_output"):
        fail(errors, "run final output did not come from final model response")
    for c in calls:
        if c.get("model") != MODEL or c.get("generation") != {"temperature": 0.0, "top_p": 1.0, "max_output_tokens": 2048}:
            fail(errors, "model-call identity or generation mismatch")
    contexts = [x.get("context") for x in policies + approvals + executions]
    if any(not isinstance(x, dict) or x.get("run_id") != run.get("id") or x.get("trace_id") != run.get("trace_id") or not x.get("tool_id") for x in contexts):
        fail(errors, "audit context did not bind to the run")
    if len({x.get("proposal_nonce") for x in policies}) != len(policies) or len({x.get("audit_sequence") for x in policies + approvals + executions}) != len(policies) + len(approvals) + len(executions):
        fail(errors, "proposal nonce or audit sequence was not unique")
    if len(policies) != len(executions): fail(errors, "proposal/dispatch count mismatch")
    # Every dispatch requires exactly one matching policy proposal and full context;
    # mutations require a matching granted approval before the execution.
    for execution in executions:
        matches = [p for p in policies if p.get("proposal_nonce") == execution.get("proposal_nonce") and p.get("context") == execution.get("context") and args(p) == args(execution)]
        if len(matches) != 1 or matches[0].get("audit_sequence", 10**9) >= execution.get("audit_sequence", -1):
            fail(errors, "dispatch lacks ordered matching policy")
        elif tool_id(execution) in {"list_tasks", "get_task"} and matches[0].get("decision", {}).get("outcome") != "allow":
            fail(errors, "read policy was not allow")
        elif tool_id(execution) == "update_task" and matches[0].get("decision", {}).get("outcome") != "require_approval":
            fail(errors, "update policy was not require_approval")
        if tool_id(execution) in {"create_task", "update_task"}:
            approved = [a for a in approvals if a.get("proposal_nonce") == execution.get("proposal_nonce") and a.get("context") == execution.get("context") and args(a) == args(execution) and a.get("record", {}).get("granted") is True]
            if len(approved) != 1 or approved[0].get("audit_sequence", 10**9) >= execution.get("audit_sequence", -1): fail(errors, "mutation lacks ordered granted approval")
        task = next((t for t in TASKS8 if t["id"] == (args(execution) or {}).get("id")), None)
        expected_output = ({"tasks": UPDATE_INITIAL} if tool_id(execution) == "list_tasks" else
                           {"task": UPDATE_FINAL[0]} if tool_id(execution) == "update_task" else
                           {"task": task})
        if tool_id(execution) == "get_task" and task is None:
            fail(errors, "get_task had an unknown ID")
        expected_result = {"ok": True, "output": expected_output}
        for key in ("underlying_result", "returned_result"):
            if execution.get(key) != expected_result: fail(errors, f"dispatch {key} mismatch")
        if execution.get("injected_failure") is not False: fail(errors, "unexpected injected fault")
        # The next model request must contain the immediately preceding assistant
        # proposal and its returned tool message.  Provider call IDs can repeat.
        occurrence = execution.get("occurrence")
        later = calls[occurrence] if isinstance(occurrence, int) and occurrence < len(calls) else {}
        transcript = later.get("transcript", []) if isinstance(later, dict) else []
        assistant = [m for m in transcript if isinstance(m, dict) and m.get("role") == "assistant"]
        tool_messages = [m for m in transcript if isinstance(m, dict) and m.get("role") == "tool"]
        call_id = execution.get("context", {}).get("call_id")
        proposed = any(any(tc.get("id") == call_id and tc.get("tool_id") == tool_id(execution) and _json_or_none(tc.get("arguments_json")) == args(execution) for tc in m.get("tool_calls", [])) for m in assistant)
        returned = any(m.get("tool_call_id") == call_id and _json_or_none(m.get("content")) == expected_result for m in tool_messages)
        if not proposed or not returned: fail(errors, "ordered proposal/result missing from later transcript")
    if case == "dependent-lookup-update":
        want = [("list_tasks", {}), ("update_task", {"id": "opaque-7", "status": "completed"})]
        if [(tool_id(x), args(x)) for x in executions] != want: fail(errors, "update dispatch sequence/arguments mismatch")
        if len(approvals) != 1 or tool_id(approvals[0]) != "update_task" or args(approvals[0]) != want[1][1] or approvals[0].get("record", {}).get("granted") is not True: fail(errors, "update approval mismatch")
        if sample.get("initial_state") != {"tasks": UPDATE_INITIAL} or sample.get("final_state") != {"tasks": UPDATE_FINAL}: fail(errors, "update fixture/final state mismatch")
        expected_final = {"status": "completed", "details": {"id": "opaque-7", "title": "Call dentist", "status": "completed"}}
        try: update_final = json.loads(run.get("final_output", "null"))
        except (json.JSONDecodeError, TypeError): update_final = None
        if update_final != expected_final: fail(errors, "update final JSON mismatch")
        if "opaque-7" in json.dumps(calls[0].get("transcript", [])): fail(errors, "opaque update ID exposed before tool result")
    else:
        got = [(tool_id(x), args(x)) for x in executions]
        if len(got) != 8 or {json.dumps(x, sort_keys=True) for x in (a for t,a in got if t == "get_task")} != {json.dumps({"id": t["id"]}, sort_keys=True) for t in TASKS8}: fail(errors, "eight reads were not exact/unique")
        if approvals or any(t not in {"get_task"} for t,a in got): fail(errors, "eight-read approval/write boundary crossed")
        if sample.get("initial_state") != {"tasks": TASKS8} or sample.get("final_state") != {"tasks": TASKS8}: fail(errors, "eight-read state mismatch")
        try: out = json.loads(run.get("final_output", "null"))
        except json.JSONDecodeError: out = None
        if not isinstance(out, dict) or out.get("status") != "ok" or set(out) != {"status", "details"} or set(out.get("details", {})) != {"tasks"} or {json.dumps(t, sort_keys=True) for t in out["details"]["tasks"]} != {json.dumps(t, sort_keys=True) for t in TASKS8} or len(out["details"]["tasks"]) != 8: fail(errors, "eight-read final JSON mismatch")
        first = json.dumps(calls[0].get("transcript", []))
        for task in TASKS8:
            if task["title"] in first: fail(errors, "hidden task title exposed before tool result")
    # The final response must have received each successfully returned result.
    final_tools = [m for m in calls[-1].get("transcript", []) if isinstance(m, dict) and m.get("role") == "tool"]
    for execution in executions:
        expected = execution.get("returned_result")
        if not any(_json_or_none(m.get("content")) == expected for m in final_tools):
            fail(errors, "final model response transcript lacked a required tool result")
    return errors


def metrics(sample, result):
    calls = sample["model_calls"]; ex = sample["tool_executions"]
    return {"evaluator_duration_ms": result["duration_ms"], "model_calls": result["model_calls"],
            "model_call_evidence": len(calls),
            "input_tokens": sum(c.get("response", {}).get("usage", {}).get("input_tokens", 0) for c in calls),
            "output_tokens": sum(c.get("response", {}).get("usage", {}).get("output_tokens", 0) for c in calls),
            "tool_attempts": sum(len(c.get("response", {}).get("tool_calls", [])) for c in calls),
            "tool_dispatches": len(ex), "approvals": len(sample["approvals"]),
            "audit_violations": len(sample.get("audit_violations", [])),
            "mutation_dispatches": sum(tool_id(x) in {"create_task", "update_task"} for x in ex),
            "actual_strategy": sample.get("strategy", {}).get("actual"),
            "fallbacks": sample.get("strategy", {}).get("fallbacks", [])}


def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--root", type=Path, required=True); ap.add_argument("--report", type=Path); ap.add_argument("--discovery-only", action="store_true"); args = ap.parse_args()
    root = args.root.resolve(); summary_path = root / "benchmark-gemma-v1" / "summary.json"
    cohort_root = root / "benchmark-gemma-v1"
    if args.discovery_only:
        errors=[]; checked=0
        for i, slot in enumerate(planned()[:4], 1):
            report = cohort_root / "discovery" / f"{i:03d}-{slot['case_id']}-{slot['requested_strategy']}" / "report.json"
            try:
                art=json.loads(report.read_text()); ev=art["evaluation"]; sample=ev["evidence"][0]; result=ev["report"]["results"][0]
            except (OSError, KeyError, IndexError, TypeError, json.JSONDecodeError) as exc:
                fail(errors, f"discovery {i} malformed: {exc}"); continue
            errors.extend(validate_sample(sample, result, slot)); checked += 1
        print(json.dumps({"mode":"discovery-only","checked":checked,"errors":errors},sort_keys=True))
        return 0 if not errors and checked == 4 else 1
    if not args.report: raise SystemExit("--report is required for a completed cohort")
    if not summary_path.is_file(): raise SystemExit("refusing incomplete cohort: final summary.json is absent")
    summary = json.loads(summary_path.read_text()); errors=[]; rows=[]; schedule=planned(); bykey={(x['phase'],x['pair_index'],x['case_id'],x['requested_strategy']):x for x in schedule}
    environment_path = root / "benchmark-environment.json"
    if not environment_path.is_file() or sha(environment_path) != ENVIRONMENT_SHA256:
        fail(errors, "benchmark environment file does not match the frozen identity")
        expected_environment = None
    else:
        expected_environment = json.loads(environment_path.read_text())
    frozen_suite = root / "frozen-inputs" / "benchmark-suite.yaml"
    suite_identity = {"path": "frozen-inputs/benchmark-suite.yaml", "expected_checkout_sha256": SUITE_SHA256,
                      "expected_normalized_git_blob_sha256": SUITE_NORMALIZED_GIT_BLOB_SHA256}
    try:
        suite_bytes = frozen_suite.read_bytes()
        normalized = suite_bytes.replace(b"\r\n", b"\n")
        suite_identity.update({"byte_length": len(suite_bytes), "crlf_count": suite_bytes.count(b"\r\n"),
                               "checkout_sha256": hashlib.sha256(suite_bytes).hexdigest(),
                               "normalized_byte_length": len(normalized),
                               "normalized_sha256": hashlib.sha256(normalized).hexdigest(),
                               "normalized_matches_immutable_blob": hashlib.sha256(normalized).hexdigest() == SUITE_NORMALIZED_GIT_BLOB_SHA256})
        if suite_identity["checkout_sha256"] != SUITE_SHA256 or not suite_identity["normalized_matches_immutable_blob"]:
            fail(errors, "portable frozen suite bytes did not match both frozen identities")
    except OSError as exc:
        suite_identity["error"] = str(exc); fail(errors, "portable frozen suite input absent")
    records=summary.get("records", [])
    expected_keys=set(bykey)
    if len(records) != 128 or len(bykey) != 128: fail(errors, "expected 128 scheduled records")
    planned_rows=[":".join((s['phase'],s['case_id'],str(s['pair_index']),s['requested_strategy'])) for s in schedule]
    if summary.get("all_planned",{}).get("count") != 128 or summary.get("all_planned",{}).get("rows") != planned_rows:
        fail(errors, "wrapper all_planned summary mismatch")
    seen=set()
    independent=[]
    for record in records:
        key=tuple(record.get(x) for x in ("phase","pair_index","case_id","requested_strategy")); slot=bykey.get(key)
        if key in seen: fail(errors, f"duplicate schedule key {key}")
        seen.add(key)
        if not slot: fail(errors, "unplanned record"); continue
        if any(record.get(k) != v for k,v in slot.items()): fail(errors, f"schedule fields mismatch {key}")
        identity = record.get("invocation_identity", {})
        if identity.get("source_commit") != COMMIT or identity.get("source_dirty") is not False or identity.get("executable_sha256") != BINARY_SHA256 or identity.get("suite_sha256") != SUITE_SHA256 or identity.get("environment_sha256") != ENVIRONMENT_SHA256:
            fail(errors, f"wrapper frozen identity {key}")
        for name in ("stdout","stderr","raw_report"):
            ref0=record.get(name, {})
            path0=(cohort_root / normref(ref0.get("path", ""))).resolve()
            try: contained=path0.is_relative_to(cohort_root.resolve())
            except ValueError: contained=False
            if not path0.is_file() or not contained or sha(path0) != ref0.get("sha256"):
                fail(errors, f"{name} reference/hash {key}")
        ref=record.get("raw_report", {}); path=(cohort_root / normref(ref.get("path", ""))).resolve()
        if not path.is_file() or not path.is_relative_to(root / "benchmark-gemma-v1") or sha(path) != ref.get("sha256"): fail(errors, f"raw report reference/hash {key}"); continue
        art=json.loads(path.read_text()); inv=art.get("invocation", {})
        if inv.get("source_commit") != COMMIT or inv.get("source_dirty") is not False or inv.get("ollama_base_url") != URL or inv.get("selected_models") != [MODEL] or inv.get("generation") != {"temperature":0.0,"top_p":1.0,"max_output_tokens":2048} or inv.get("limits") != {"max_model_calls":9,"max_tool_calls":8,"max_run_duration_ms":300000,"max_model_call_duration_ms":120000}: fail(errors, f"invocation identity {key}")
        models=inv.get("environment",{}).get("models",[])
        if not any(x.get("name")==MODEL and x.get("digest")==MODEL_DIGEST for x in models): fail(errors, f"model digest {key}")
        if inv.get("environment") != expected_environment: fail(errors, f"environment content {key}")
        ev=art.get("evaluation",{}); results=ev.get("report",{}).get("results",[]); samples=ev.get("evidence",[])
        if len(results)!=1 or len(samples)!=1: fail(errors, f"raw shape {key}"); continue
        row_errors=validate_sample(samples[0],results[0],slot)
        errors.extend(f"{key}: {x}" for x in row_errors)
        independent_pass=not row_errors
        if independent_pass != record.get("fully_passed"): fail(errors, f"wrapper verdict mismatch {key}")
        metric=metrics(samples[0],results[0]); rows.append((slot,metric,independent_pass)); independent.append((slot,metric,independent_pass))
    if seen != set(bykey): fail(errors, "missing scheduled rows")
    # Recompute only measured paired outcomes; compare the driver's key published values.
    paired={}
    for slot,m,passed in rows:
        if slot['phase']=='measured' and passed: paired[(slot['case_id'],slot['pair_index'],slot['requested_strategy'])]=m
    pair_report={}; total_n=0
    for case in CASES:
        deltas=defaultdict(list); excluded=[]
        for pair in range(1,31):
            d=paired.get((case,pair,'direct')); a=paired.get((case,pair,'adaptive'))
            if not d or not a: excluded.append(pair); continue
            total_n+=1
            for metric in ("evaluator_duration_ms","model_calls","input_tokens","output_tokens","tool_attempts","tool_dispatches","mutation_dispatches"): deltas[metric].append(a[metric]-d[metric])
        pair_report[case]={"paired_n":30-len(excluded),"excluded_pair_indexes":excluded,"median_adaptive_minus_direct":{k:statistics.median(v) for k,v in deltas.items()}}
    reported=summary.get("paired_measurements",{})
    if reported.get("total_paired_n") != total_n or reported.get("per_case") != {k:{**reported.get("per_case",{}).get(k,{}), **pair_report[k]} for k in CASES}: fail(errors, "driver paired summary mismatch")
    def total(items):
        out=Counter()
        for _, m, _ in items:
            for k in ("model_calls","model_call_evidence","input_tokens","output_tokens","tool_attempts","tool_dispatches","audit_violations","mutation_dispatches"):
                out[k]+=m[k]
        out['rows']=len(items); out['fully_passed_rows']=sum(p for _,_,p in items); return dict(out)
    phase={phase:total([x for x in independent if x[0]['phase']==phase]) for phase in ('discovery','warmup','measured')}
    def per_case(items):
        out={}
        for case in CASES:
            group=[x for x in items if x[0]['case_id']==case]
            requested=Counter(x[0]['requested_strategy'] for x in group)
            actual=Counter(x[1]['actual_strategy'] for x in group if x[1]['actual_strategy'] is not None)
            fallbacks=Counter(json.dumps(x[1]['fallbacks'],sort_keys=True) for x in group if x[1]['fallbacks'])
            out[case]={"requested_strategy_counts":dict(sorted(requested.items())),"actual_strategy_counts":dict(sorted(actual.items())),"fallback_sequences":dict(sorted(fallbacks.items())),"fully_passed":sum(x[2] for x in group),"metrics":total(group)}
        return out
    if summary.get('totals') != total([x for x in independent if x[0]['phase']=='measured']): fail(errors,'wrapper measured totals mismatch')
    if any(summary.get('phases',{}).get(p,{}).get('totals') != phase[p] or summary.get('phases',{}).get(p,{}).get('planned') != len([s for s in schedule if s['phase']==p]) for p in phase): fail(errors,'wrapper phase totals mismatch')
    if summary.get('per_case') != per_case([x for x in independent if x[0]['phase']=='measured']): fail(errors,'wrapper measured per-case summary mismatch')
    if any(summary.get('phases',{}).get(p,{}).get('per_case') != per_case([x for x in independent if x[0]['phase']==p]) for p in phase): fail(errors,'wrapper phase per-case summary mismatch')
    if summary.get('completed',{}).get('count') != 128 or summary.get('completed',{}).get('rows') != planned_rows or summary.get('missing',{}).get('count') != 0 or summary.get('missing',{}).get('rows') != []: fail(errors,'wrapper completed/missing counts mismatch')
    output={"format_version":1,"verdict":"GO" if not errors else "NO-GO","errors":errors,"raw_rows_validated":len(rows),"expected_rows":128,"suite_identity":suite_identity,"suite_identity_note":"The preserved initial audit used the immutable LF blob hash where the driver correctly recorded CRLF checkout bytes; this is an audit expectation mismatch, not changed benchmark evidence.","phase_totals":phase,"per_case":per_case([x for x in independent if x[0]['phase']=='measured']),"paired_measurements":{"total_paired_n":total_n,"per_case":pair_report},"summary_sha256":sha(summary_path)}
    args.report.write_text(json.dumps(output,indent=2)+"\n",encoding="utf-8")
    print(json.dumps({"verdict":output["verdict"],"errors":len(errors),"rows":len(rows)},sort_keys=True))
    return 0 if not errors else 1

if __name__ == "__main__": raise SystemExit(main())
