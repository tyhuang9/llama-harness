import assert from "node:assert/strict";
import { createHash } from "node:crypto";
import { readFileSync } from "node:fs";
import { resolve, sep } from "node:path";
import { fileURLToPath } from "node:url";

delete process.env.LLAMA_HARNESS_RUNTIME_PATH;
delete process.env.NODE_PATH;
const { HarnessClient, resolveRuntimePath } = await import("@llama-harness/sdk");
assert.ok(fileURLToPath(import.meta.resolve("@llama-harness/sdk")).startsWith(resolve("node_modules") + sep));
const runtime = resolve(resolveRuntimePath());
assert.ok(runtime.startsWith(resolve("node_modules") + sep));
const expected = JSON.parse(readFileSync("../../combined-artifacts/release-manifest.json", "utf8"))
  .artifacts.find(entry => entry.path === "llama-harness-runtime-win32-x64.exe");
assert.equal(createHash("sha256").update(readFileSync(runtime)).digest("hex"), expected.sha256);
const client = await HarnessClient.start({ provider: { kind: "ollama" } });
try {
  assert.equal(client.negotiatedProtocolVersion, "1.1");
  console.log(JSON.stringify({ sdk: "@llama-harness/sdk", version: "0.2.0",
    runtime, runtime_sha256: expected.sha256, protocol: client.negotiatedProtocolVersion,
    override_used: false, model_calls: 0 }));
} finally {
  await client.close();
}
