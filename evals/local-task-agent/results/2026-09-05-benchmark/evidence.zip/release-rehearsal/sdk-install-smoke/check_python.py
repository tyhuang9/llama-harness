import asyncio
import hashlib
from importlib.metadata import version
import json
import os
from pathlib import Path
import sys

os.environ.pop("LLAMA_HARNESS_RUNTIME_PATH", None)
import llama_harness
from llama_harness import HarnessClient
from llama_harness.client import resolve_runtime_path

ROOT = Path(__file__).resolve().parent.parent
runtime = Path(resolve_runtime_path()).resolve()
if not runtime.is_relative_to(Path(sys.prefix).resolve()):
    raise RuntimeError("Runtime was not resolved from the isolated installed wheel")
if not Path(llama_harness.__file__).resolve().is_relative_to(Path(sys.prefix).resolve()):
    raise RuntimeError("SDK import did not come from the installed wheel")
if version("llama-harness") != "0.2.0":
    raise RuntimeError("Installed SDK version mismatch")
manifest = json.loads((ROOT / "combined-artifacts/release-manifest.json").read_text())
expected = next(entry for entry in manifest["artifacts"]
                if entry["path"] == "llama-harness-runtime-win32-x64.exe")
if hashlib.sha256(runtime.read_bytes()).hexdigest() != expected["sha256"]:
    raise RuntimeError("Wheel runtime bytes differ from the reviewed CI runtime")

async def check():
    async with await HarnessClient.start(provider={"kind": "ollama"}) as client:
        if client.protocol_version != "1.1":
            raise RuntimeError("Expected protocol 1.1")
        print(json.dumps({"sdk": "llama-harness", "version": version("llama-harness"),
                          "runtime": str(runtime), "runtime_sha256": expected["sha256"],
                          "protocol": client.protocol_version, "override_used": False,
                          "model_calls": 0}))

asyncio.run(asyncio.wait_for(check(), timeout=20))
