# llama-harness 0.2.0 — prepared release

Release preparation passed for reviewed main
`f545bd524c622689fc92daf51e6c0e7f17c63175`. No packages, tags, or GitHub release
have been published by this work. The user's manual crates.io step remains
pending.

## Verified

- [Main continuous verification](https://github.com/tyhuang9/llama-harness/actions/runs/33990319828): 13/13 jobs passed.
- [Rust release rehearsal](https://github.com/tyhuang9/llama-harness/actions/runs/33990339151): 8/8 jobs passed, including Rust 1.88 fresh resolution, all platform crate sets, advisory/license/source policy, API/docs and packaged consumers.
- [Runtime and SDK rehearsal](https://github.com/tyhuang9/llama-harness/actions/runs/33990343206): 7/7 jobs passed, including Windows x64, macOS arm64, Linux x64 and the combined manifest.
- All ten downloaded runtime/npm/wheel payloads passed local package-content, manifest and checksum inspection. The downloaded Windows runtime completed the protocol 1.1 version handshake as 0.2.0.
- Eight local Rust archives were staged from clean main. Their embedded source IDs match the reviewed commit; hashes are in `artifact-provenance.json`.
- The final-source version/MSRV/eight-crate preflight passed. The sandbox's `cargo publish --locked --dry-run` passed and explicitly aborted its upload.
- Fresh offline Windows SDK installations passed: Python 3.12.10 in a new venv and Node 24.15.0/npm 12.0.1 with fresh dependencies. Each resolved its packaged runtime, matched the reviewed runtime hash, negotiated protocol 1.1 as version 0.2.0, and closed without a runtime override or model call. Results, scripts and logs are in `sdk-install-smoke/`; these are local artifact installation checks, not registry installs.

The first rehearsal caught missing formatter/linter components in the manual
workflow. [PR #38](https://github.com/tyhuang9/llama-harness/pull/38) fixed that
one-line setup defect, passed all 34 PR/push CI jobs, and was merged with the
user's specific approval. The successful workflows above ran after that merge.
The original failure and earlier-source evidence remain in the parent folder.

## Remaining publication sequence

Use the existing repository [release runbook](https://github.com/tyhuang9/llama-harness/blob/f545bd524c622689fc92daf51e6c0e7f17c63175/docs/releasing.md).
The registry-dependent steps have not been simulated or marked complete:

1. Complete the user-owned crates.io account/package step and confirm the
   intended ownership, including the project's backup-owner requirement.
2. Recheck the clean approved source and exact 0.2.0 registry state immediately
   before publication. Publish the sandbox, core, direct integrations, evals,
   and facade in the documented dependency order. Wait for each layer to be
   indexed and build fresh exact-version consumers without local overrides.
3. Verify all intended published packages, owners, installation, and docs.rs.
   If npm/PyPI distribution is included, confirm those registry identities and
   access separately; their packages are prepared but not published.
4. Create the tag and GitHub release only after all intended registry packages
   have been confirmed. An existing version is immutable; stop rather than
   overwriting it.

The retained snapshots found all eight crate names unregistered at 20:13 UTC
and the four npm package names plus the Python package unregistered at 20:39 UTC
on September 5. A 404 does not establish account or namespace ownership.

The local Rust gate on preceding main passed 492 tests with two ignored; Rust
source was identical across the workflow-only fix. The exact final commit was
then validated again by the successful GitHub gates above. Cargo's packaging
warning about an unselected yanked `chacha20 0.10.1` lock entry is retained in
the logs. The all-feature/all-target inverse tree found no selected path and
the existing policy gate passed without an exemption; recheck current registry
and advisory state before publishing.

Live-model and benchmark evidence is separate from package integrity. Gemma's
guided task suite passed; the measured LFM profile remains unqualified, and
Ollama's Adaptive samples used Direct fallback. No advanced-strategy activation
or general production-reliability claim is part of this release preparation.
