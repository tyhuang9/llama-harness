"""Ephemeral loopback diagnostic: retain synthetic request and public response only."""
import http.client
import http.server
import json
from pathlib import Path
import subprocess
import threading

root = Path(__file__).resolve().parent
workspace = root.parent / "worktrees" / "live-model-tool-calling"
captured = []

def upstream(method, path, body=None):
    connection = http.client.HTTPConnection("::1", 11434, timeout=120)
    try:
        connection.request(method, path, body=body, headers={"Content-Type": "application/json"})
        response = connection.getresponse()
        return response.status, response.read()
    finally:
        connection.close()

def safe_response(body):
    data = json.loads(body)
    message = data.get("message", {})
    return {"model": data.get("model"), "content": message.get("content"),
            "tool_calls": message.get("tool_calls", []),
            "thinking_character_count": len(message.get("thinking", "")),
            **{key: data.get(key) for key in ("done", "done_reason", "prompt_eval_count", "eval_count", "total_duration", "load_duration")}}

class Forwarder(http.server.BaseHTTPRequestHandler):
    def log_message(self, *_args):
        pass

    def forward(self):
        if (self.command, self.path) not in (("GET", "/api/version"), ("GET", "/api/tags"), ("POST", "/api/chat")):
            self.send_error(404)
            return
        length = int(self.headers.get("Content-Length", 0))
        if length > 1024 * 1024:
            self.send_error(413)
            return
        body = self.rfile.read(length) if length else None
        status, response = upstream(self.command, self.path, body)
        if self.path == "/api/chat":
            captured.append({"request": json.loads(body), "upstream_status": status, "response": safe_response(response)})
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(response)))
        self.end_headers()
        self.wfile.write(response)

    do_GET = forward
    do_POST = forward

server = http.server.HTTPServer(("127.0.0.1", 0), Forwarder)
thread = threading.Thread(target=server.serve_forever, daemon=True)
thread.start()
try:
    args = [str(root / "bin/live-task-agent-eval-prompt3.exe"), "--ollama-url", f"http://127.0.0.1:{server.server_port}",
            "--model", "lfm2.5-thinking:1.2b-q4_K_M", "--strategy", "direct", "--case", "approved-mutation",
            "--repeat", "1", "--temperature", "0", "--top-p", "1", "--output-tokens", "2048",
            "--max-model-call-duration-ms", "120000", "--max-run-duration-ms", "300000",
            "--environment-json", str(root / "environment-v3.json"), "--output", str(root / "lfm-wire-harness.json")]
    result = subprocess.run(args, cwd=workspace, capture_output=True, text=True, timeout=310)
    (root / "lfm-wire-harness.log").write_text(result.stdout + result.stderr, encoding="utf-8")
finally:
    server.shutdown()
    server.server_close()
    thread.join(timeout=2)
assert captured, "No live chat request crossed diagnostic proxy"
request = captured[0]["request"]
status, replay = upstream("POST", "/api/chat", json.dumps(request).encode())
report = {"label": "Identical synthetic first-turn payload through harness then native Ollama; no hidden reasoning retained",
          "backend": "http://[::1]:11434", "harness_exit_code": result.returncode,
          "captured_harness_calls": captured, "native_replay": {"request": request, "status": status, "response": safe_response(replay)}}
(root / "lfm-wire-diagnostic.json").write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
print(json.dumps({"harness_exit_code": result.returncode, "harness_upstream": captured[0]["response"], "native_replay": report["native_replay"]["response"]}, indent=2))
