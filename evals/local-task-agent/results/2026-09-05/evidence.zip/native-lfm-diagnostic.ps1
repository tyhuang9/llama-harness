$ErrorActionPreference = 'Stop'
$evidenceRoot = Split-Path -Parent $PSCommandPath
$requestData = [ordered]@{
    model = 'lfm2.5-thinking:1.2b-q4_K_M'
    stream = $false
    messages = @(
        [ordered]@{role='system'; content='You are a task assistant. Use create_task to create the task requested by the user. Do not invent task results.'},
        [ordered]@{role='user'; content='Create one task titled Native calibration. Call create_task now.'}
    )
    tools = @(
        [ordered]@{
            type='function'
            function=[ordered]@{
                name='create_task'; description='Create a new task.'
                parameters=[ordered]@{
                    type='object'; required=@('title'); additionalProperties=$false
                    properties=[ordered]@{title=[ordered]@{type='string'}}
                }
            }
        }
    )
    options=[ordered]@{temperature=0;top_p=1;num_predict=2048}
}
$samples = @()
foreach ($budget in @(2048,8192)) {
    $requestData.options.num_predict = $budget
    $requestJson = $requestData | ConvertTo-Json -Depth 12
    $startedAt = [DateTime]::UtcNow
    $responseData = Invoke-RestMethod -Uri 'http://[::1]:11434/api/chat' -Method Post -ContentType 'application/json' -Body $requestJson -TimeoutSec 120
    $samples += [ordered]@{
        label='native request-only diagnostic; no tool dispatch or harness execution'
        started_at_utc=$startedAt.ToString('o')
        request=($requestJson | ConvertFrom-Json)
        response=[ordered]@{
            model=$responseData.model;content=$responseData.message.content;tool_calls=$responseData.message.tool_calls
            thinking_character_count=([string]$responseData.message.thinking).Length
            done=$responseData.done;done_reason=$responseData.done_reason
            input_tokens=$responseData.prompt_eval_count;output_tokens=$responseData.eval_count
            total_duration_ns=$responseData.total_duration;load_duration_ns=$responseData.load_duration
        }
    }
    $samples | ConvertTo-Json -Depth 15 | Set-Content -LiteralPath (Join-Path $evidenceRoot 'native-lfm-diagnostic.json') -Encoding utf8
    $toolCallCount = @($responseData.message.tool_calls | Where-Object { $null -ne $_ }).Count
    Write-Output "Native request budget $budget : $toolCallCount tool calls; done_reason=$($responseData.done_reason), output_tokens=$($responseData.eval_count)"
}
