use llama_harness::{
    ollama::OllamaProvider, EventSink, GenerationOptions, InMemoryEventSink, ModelProvider,
    RunRequest, RunStatus, RunStrategy,
};
use local_task_agent::{build_runtime, Task, TaskStore};
use serde_json::json;
use std::{sync::Arc, time::Duration};

#[tokio::main]
async fn main() -> Result<(), Box<dyn std::error::Error>> {
    let model = std::env::args().nth(1).ok_or("installed model required")?;
    let provider = Arc::new(OllamaProvider::builder().request_timeout(Duration::from_secs(120)).build()?);
    let health = provider.health().await?;
    if !health.healthy { return Err("Ollama unavailable".into()); }
    if !provider.list_models().await?.iter().any(|entry| entry.id == model) {
        return Err("model is not installed".into());
    }
    let store = Arc::new(TaskStore::new(Vec::<Task>::new())?);
    let events = Arc::new(InMemoryEventSink::default());
    let mut runtime = build_runtime(provider, store.clone(), model, true, events.clone() as Arc<dyn EventSink>)?;
    runtime.agent.generation = GenerationOptions { temperature: Some(0.0), top_p: Some(1.0), max_output_tokens: Some(2048) };
    runtime.agent.limits.max_run_duration_ms = Some(180_000);
    runtime.agent.limits.max_model_call_duration_ms = Some(120_000);
    runtime.agent.limits.max_provider_retries = 0;
    let input = "Create exactly one task titled Calibration task using create_task. After the tool succeeds, reply with only a JSON object containing the created task's id, title, and status. Do not claim creation before the tool result confirms it.";
    let result = runtime.runner.run_with_strategy(RunRequest::new(runtime.agent.clone(), input), RunStrategy::Direct).await?;
    let final_state = store.snapshot()?;
    let answer = result.final_output.as_deref().and_then(|output| serde_json::from_str::<serde_json::Value>(output).ok());
    let expected = json!({"id":"task-1","title":"Calibration task","status":"open"});
    let passed = result.status == RunStatus::Completed && result.tool_calls.len() == 1 && result.approvals.len() == 1 && result.approvals[0].granted && serde_json::to_value(&final_state)? == json!([expected]) && answer == Some(expected);
    println!("{}", serde_json::to_string_pretty(&json!({"harness_source_commit":"8e52758de961d0dc289353f803a125c32f25fd18","probe_version":1,"input":input,"generation":runtime.agent.generation,"health":health,"requested_strategy":"direct","events":events.events(),"run":result,"final_state":final_state,"passed":passed}))?);
    if !passed { return Err("Direct calibration assertions failed".into()); }
    Ok(())
}

