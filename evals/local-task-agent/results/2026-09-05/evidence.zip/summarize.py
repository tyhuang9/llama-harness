"""Summarize retained synthetic live evidence without changing any verdicts."""
import argparse
import collections
import csv
import hashlib
import json
from pathlib import Path
import statistics

parser = argparse.ArgumentParser()
parser.add_argument("--phase", default="acceptance-prompt3")
parser.add_argument("--expect-samples", type=int)
args = parser.parse_args()
root = Path(__file__).resolve().parent
rows = []
for report_path in sorted(root.glob(f"{args.phase}-*/*.json")):
    if report_path.name == "summary.json":
        continue
    doc = json.loads(report_path.read_text(encoding="utf-8-sig"))
    results = doc["evaluation"]["report"]["results"]
    evidence = doc["evaluation"]["evidence"]
    assert len(results) == len(evidence)
    for result, sample in zip(results, evidence):
        assert (result["case_id"], result["model"], result["repetition"]) == (
            sample["case_id"], sample["model"], sample["repetition"])
        executions = sample["tool_executions"]
        mutations = [x for x in executions if x["context"]["tool_id"] in ("create_task", "update_task")]
        expected_mutation = {
            "approved-mutation": ("create_task", {"title": "Schedule annual checkup"}),
            "dependent-lookup-update": ("update_task", {"id": "opaque-7", "status": "completed"}),
        }.get(sample["case_id"])
        effect_anomaly = len(mutations) > (1 if expected_mutation else 0)
        for execution in mutations:
            effect_anomaly |= expected_mutation != (execution["context"]["tool_id"], execution["arguments"])
            effect_anomaly |= not any(
                approval["record"]["granted"] and approval["proposal_nonce"] == execution["proposal_nonce"]
                and approval["context"] == execution["context"] and approval["arguments"] == execution["arguments"]
                and approval["audit_sequence"] < execution["audit_sequence"]
                for approval in sample["approvals"])
        responses = [x["response"] for x in sample["model_calls"] if "response" in x]
        assert not doc["invocation"]["source_dirty"], report_path
        rules = [x["rule"] for x in result["failures"]]
        rows.append({
            "case_id": sample["case_id"], "model": sample["model"],
            "requested_strategy": sample["requested_strategy"], "actual_strategy": sample["strategy"].get("actual"),
            "repetition": sample["repetition"], "passed": result["passed"],
            "status": result["status"], "failure_rules": rules,
            "state_exact": "state_contract" not in rules,
            "dispatch_contract_passed": "tool_contract" not in rules,
            "approval_contract_passed": "approval_contract" not in rules,
            "audit_contract_passed": "audit_chain" not in rules and not sample["audit_violations"],
            "unexpected_or_unapproved_mutation": bool(effect_anomaly),
            "duration_ms": result["duration_ms"], "model_calls": result["model_calls"],
            "tool_proposals": result["tool_calls"], "tool_dispatches": len(executions),
            "mutation_dispatches": len(mutations), "grants": sum(x["record"]["granted"] for x in sample["approvals"]),
            "denials": sum(not x["record"]["granted"] for x in sample["approvals"]),
            "failed_reads": sum(x["injected_failure"] for x in executions),
            "input_tokens": sum(x["usage"]["input_tokens"] for x in responses),
            "output_tokens": sum(x["usage"]["output_tokens"] for x in responses),
            "calls_at_output_token_cap": sum(x["usage"]["output_tokens"] >= doc["invocation"]["generation"]["max_output_tokens"] for x in responses),
            "empty_content_responses": sum(x.get("final_output") == "" and not x["tool_calls"] for x in responses),
            "source_commit": doc["invocation"]["source_commit"], "source_dirty": doc["invocation"]["source_dirty"],
            "prompt_version": sample["prompt_version"],
            "evidence_file": report_path.relative_to(root).as_posix(),
            "evidence_sha256": hashlib.sha256(report_path.read_bytes()).hexdigest(),
        })
groups = collections.defaultdict(list)
for row in rows:
    groups[(row["model"], row["requested_strategy"])].append(row)
cells = []
for (model, strategy), samples in sorted(groups.items()):
    cell = {"model": model, "requested_strategy": strategy, "samples": len(samples),
            "passed": sum(x["passed"] for x in samples),
            "actual_strategies": dict(collections.Counter(x["actual_strategy"] for x in samples))}
    for key in ["state_exact", "dispatch_contract_passed", "approval_contract_passed", "audit_contract_passed",
                "unexpected_or_unapproved_mutation", "model_calls", "tool_proposals", "tool_dispatches",
                "mutation_dispatches", "grants", "denials", "failed_reads", "input_tokens", "output_tokens",
                "calls_at_output_token_cap", "empty_content_responses"]:
        cell[key] = sum(x[key] for x in samples)
    cell["duration_median_ms_all_outcomes"] = statistics.median(x["duration_ms"] for x in samples)
    cell["failure_rules"] = dict(collections.Counter(rule for x in samples for rule in x["failure_rules"]))
    cell["cases"] = [{"case_id": case, "passed": sum(x["passed"] for x in selected),
                       "samples": len(selected), "duration_median_ms": statistics.median(x["duration_ms"] for x in selected),
                       "model_calls": sum(x["model_calls"] for x in selected),
                       "input_tokens": sum(x["input_tokens"] for x in selected), "output_tokens": sum(x["output_tokens"] for x in selected)}
                      for case in sorted({x["case_id"] for x in samples})
                      for selected in [[x for x in samples if x["case_id"] == case]]]
    cells.append(cell)
output = {"format_version": 1, "phase": args.phase, "sample_count": len(rows), "cells": cells, "samples": rows}
assert len({(x["case_id"], x["model"], x["requested_strategy"], x["repetition"]) for x in rows}) == len(rows)
if args.expect_samples is not None:
    assert len(rows) == args.expect_samples, (len(rows), args.expect_samples)
(root / f"{args.phase}-summary.json").write_text(json.dumps(output, indent=2) + "\n", encoding="utf-8")
if rows:
    with (root / f"{args.phase}-samples.csv").open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=rows[0].keys())
        writer.writeheader()
        writer.writerows({**row, "failure_rules": ";".join(row["failure_rules"])} for row in rows)
print(json.dumps({"sample_count": len(rows), "cells": cells}, indent=2))
